from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from petguard import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/animais/', views.listar_animais, name='listar_animais'),
    path('add-animal/', views.add_animal, name='add_animal'),
    path('', include('petguard.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
